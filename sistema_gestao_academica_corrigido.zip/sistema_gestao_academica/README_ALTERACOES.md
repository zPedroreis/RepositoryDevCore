# Alterações do Sistema de Gestão Acadêmica

## Novo fluxo de acesso

1. O usuário informa o **CPF**.
2. O sistema procura o CPF na tabela `usuarios`.
3. A senha inicial de novos usuários é **SesiSenai@2026**.
4. O banco marca o usuário com `senha_provisoria = 1`.
5. No primeiro login, o sistema bloqueia o restante da aplicação e abre `alterar_senha.php`.
6. O usuário cria uma senha pessoal.
7. A senha pessoal é armazenada somente como hash e `senha_provisoria` passa para `0`.
8. Depois disso, o usuário acessa normalmente.

## Cadastro de usuários

A opção **Criar nova conta** foi removida.

Não existe mais cadastro de aluno ou instrutor pela interface.

Novos alunos e instrutores devem ser cadastrados diretamente no MySQL. A senha inicial deve ser o hash da senha padrão e `senha_provisoria` deve ficar em `1`.

## Perfil

O perfil continua sendo definido pelo banco:

- `ALUNO`
- `INSTRUTOR`

O CPF continua sendo a identificação usada no login.

## Banco novo

Se for criar o banco do zero, importe:

`database.sql`

Ele já contém a coluna `senha_provisoria`, os usuários de demonstração e a senha padrão.

## Banco existente

Se você já possui o banco preenchido e não quer apagá-lo, execute:

`migracao_senha_padrao.sql`

Essa migração adiciona a coluna e faz os usuários existentes voltarem para a senha padrão, obrigando a troca no próximo login.

## Observação importante

A senha padrão é apenas uma senha temporária. A aplicação nunca grava a senha pessoal em texto puro; ela é protegida com `password_hash()`.

