<?php

class Database {
    public static function getConnection() {
        return new PDO("mysql:host=localhost;dbname=sistema_alocacao;charset=utf8", "root", "sua_senha");
    }
}