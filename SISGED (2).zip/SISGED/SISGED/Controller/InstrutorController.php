<?php
require_once __DIR__ . '/../Model/Instrutor.php';

class InstrutorController {

    public function index() {
        $instrutores = Instrutor::listar();
        require_once __DIR__ . '/../index.final.html';
    }

    public function criar() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nome     = $_POST['nome'] ?? '';
            $area     = $_POST['area'] ?? '';
            $email    = $_POST['email'] ?? '';
            $telefone = $_POST['telefone'] ?? '';

            if (!empty($nome) && !empty($email)) {
                Instrutor::salvar($nome, $area, $email, $telefone);
                header('Location: index.php?rota=instrutores');
                exit;
            }
        }
    }
}