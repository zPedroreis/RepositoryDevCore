<?php
require_once __DIR__ . '/../Model/Instrutor.php';
require_once __DIR__ . '/../Model/Materia.php';

class DashboardController {

    public function index() {
        // Busca estatísticas gerais para alimentar os cards do HTML
        $totalInstrutores = Instrutor::contar();
        $totalMaterias = Materia::contar();
        
        require_once __DIR__ . '/../final.html';
    }
}