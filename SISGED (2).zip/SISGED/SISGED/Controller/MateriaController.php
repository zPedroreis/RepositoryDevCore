<?php
require_once __DIR__ . '/../Model/Materia.php';

class MateriaController {
    public function index() {
        $materias = Materia::listar();
        require_once __DIR__ . '/../View/Materiais/index.php';
    }

    public function criar() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $area_id = $_POST['area_id'] ?? null;
            $modalidade_id = $_POST['modalidade_id'] ?? null;

            Materia::salvar($area_id, $modalidade_id);
            header('Location: index.php?rota=materias');
            exit;
        }
        require_once __DIR__ . '/../View/Materiais/criar.php';
    }
}