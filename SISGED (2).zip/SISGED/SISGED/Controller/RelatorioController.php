<?php
require_once __DIR__ . '/../Config/database.php';

class RelatorioController {
    public function index() {
        $db = Database::getConnection();
        $sql = "SELECT a.id_alocacao_aula, i.nome AS instrutor, s.nome AS sala, h.dia_semana, h.hora_inicio 
                FROM alocacao_aula a
                INNER JOIN instrutor i ON a.instrutor_id_instrutor = i.id_instrutor
                INNER JOIN sala s ON a.sala_id_sala = s.id_sala
                INNER JOIN horario h ON a.horario_id_horario = h.id_horario";
        
        $stmt = $db->query($sql);
        $relatorios = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Exibe uma view simples de relatório ou inclui uma tela
        require_once __DIR__ . '/../View/Materiais/index.php'; // Ou crie uma pasta View/Relatorios
    }
}