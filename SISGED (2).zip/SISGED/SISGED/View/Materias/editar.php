<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Editar Matéria</title>
    <link rel="stylesheet" href="../../final.css">
</head>
<body>
    <h1>Editar Matéria</h1>
    <form action="index.php?rota=materias_editar&id=<?= $materia['id_curso'] ?>" method="POST">
        <label>ID da Área:</label><br>
        <input type="number" name="area_id" value="<?= $materia['area_id_area'] ?? '' ?>" required><br><br>

        <label>ID da Modalidade:</label><br>
        <input type="number" name="modalidade_id" value="<?= $materia['modalidades_id_modalidades'] ?? '' ?>" required><br><br>

        <button type="submit">Atualizar</button>
        <a href="index.php?rota=materias">Cancelar</a>
    </form>
</body>
</html>