<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Lista de Matérias</title>
    <link rel="stylesheet" href="final.css">
</head>
<body>
    <h1>Matérias / Cursos</h1>
    <a href="index.php?rota=materias_criar">+ Nova Matéria</a>
    
    <table border="1" cellpadding="8">
        <thead>
            <tr>
                <th>ID</th>
                <th>Área</th>
                <th>Modalidade</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($materias)): ?>
                <?php foreach ($materias as $mat): ?>
                    <tr>
                        <td><?= $mat['id_curso'] ?></td>
                        <td><?= htmlspecialchars($mat['area_id_area'] ?? '') ?></td>
                        <td><?= htmlspecialchars($mat['modalidades_id_modalidades'] ?? '') ?></td>
                        <td>
                            <a href="index.php?rota=materias_editar&id=<?= $mat['id_curso'] ?>">Editar</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="4">Nenhuma matéria registrada.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html>