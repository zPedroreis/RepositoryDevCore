<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Nova Matéria</title>
    <link rel="stylesheet" href="../../final.css">
</head>
<body>
    <h1>Cadastrar Matéria</h1>
    <form action="index.php?rota=materias_criar" method="POST">
        <label>ID da Área:</label><br>
        <input type="number" name="area_id" required><br><br>

        <label>ID da Modalidade:</label><br>
        <input type="number" name="modalidade_id" required><br><br>

        <button type="submit">Salvar</button>
        <a href="index.php?rota=materias">Cancelar</a>
    </form>
</body>
</html>