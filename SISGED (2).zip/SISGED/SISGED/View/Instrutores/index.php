<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Lista de Instrutores</title>
    <link rel="stylesheet" href="../../final.css">
</head>
<body>
    <h1>Instrutores</h1>
    <a href="index.php?rota=instrutores_criar">+ Novo Instrutor</a>
    
    <table border="1" cellpadding="8">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nome</th>
                <th>CPF</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($instrutores)): ?>
                <?php foreach ($instrutores as $inst): ?>
                    <tr>
                        <td><?= $inst['id_instrutor'] ?></td>
                        <td><?= htmlspecialchars($inst['nome']) ?></td>
                        <td><?= htmlspecialchars($inst['cpf']) ?></td>
                        <td>
                            <a href="index.php?rota=instrutores_editar&id=<?= $inst['id_instrutor'] ?>">Editar</a> | 
                            <a href="index.php?rota=instrutores_excluir&id=<?= $inst['id_instrutor'] ?>" onclick="return confirm('Excluir este instrutor?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="4">Nenhum instrutor cadastrado.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html>