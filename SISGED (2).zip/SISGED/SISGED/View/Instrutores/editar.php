<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Editar Instrutor</title>
    <link rel="stylesheet" href="../../final.css">
</head>
<body>
    <h1>Editar Instrutor</h1>
    <form action="index.php?rota=instrutores_editar&id=<?= $instrutor['id_instrutor'] ?>" method="POST">
        <label>Nome:</label><br>
        <input type="text" name="nome" value="<?= htmlspecialchars($instrutor['nome']) ?>" required><br><br>

        <label>CPF:</label><br>
        <input type="text" name="cpf" value="<?= htmlspecialchars($instrutor['cpf']) ?>" maxlength="11" required><br><br>

        <button type="submit">Atualizar</button>
        <a href="index.php?rota=instrutores">Cancelar</a>
    </form>
</body>
</html>