<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Cadastrar Instrutor</title>
</head>
<body>
    <h1>Novo Instrutor</h1>
    <form action="index.php?rota=instrutores_criar" method="POST">
        <label>Nome:</label><br>
        <input type="text" name="nome" required><br><br>

        <label>CPF:</label><br>
        <input type="text" name="cpf" maxlength="11" required><br><br>

        <button type="submit">Salvar</button>
        <a href="index.php?rota=instrutores">Cancelar</a>
    </form>
</body>
</html>