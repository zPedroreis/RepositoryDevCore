<?php
require_once __DIR__ . '/../Config/database.php';

class Usuario {
    public static function buscarPorEmail($email) {
        $db = Database::getConnection();
        $stmt = $db->prepare("SELECT id_usuario, nome, email, senha, perfil FROM usuario WHERE email = :email AND ativo = TRUE");
        $stmt->execute([':email' => $email]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public static function criar($nome, $email, $senha, $perfil) {
        $db = Database::getConnection();
        $hashSenha = password_hash($senha, PASSWORD_BCRYPT);
        $stmt = $db->prepare("INSERT INTO usuario (nome, email, senha, perfil) VALUES (:nome, :email, :senha, :perfil)");
        return $stmt->execute([
            ':nome' => $nome,
            ':email' => $email,
            ':senha' => $hashSenha,
            ':perfil' => $perfil
        ]);
    }
}