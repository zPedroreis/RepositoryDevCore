<?php
require_once __DIR__ . '/../Config/database.php';

class Materia {
    public static function listar() {
        $db = Database::getConnection();
        $stmt = $db->query("SELECT * FROM curso");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function salvar($area_id, $modalidade_id, $coordenacao_id = 1, $datas_feriados_id = 1) {
        $db = Database::getConnection();
        $sql = "INSERT INTO curso (area_id_area, modalidades_id_modalidades, coordenacao_id_coordenacao, datas_feriados_id_datas_feriados) 
                VALUES (:area, :modalidade, :coordenacao, :feriados)";
        $stmt = $db->prepare($sql);
        return $stmt->execute([
            ':area' => $area_id,
            ':modalidade' => $modalidade_id,
            ':coordenacao' => $coordenacao_id,
            ':feriados' => $datas_feriados_id
        ]);
    }
}