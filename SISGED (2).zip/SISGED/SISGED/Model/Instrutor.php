<?php
require_once __DIR__ . '/../Config/database.php';

class Instrutor {

    public static function listar() {
        $db = Database::getConnection();
        $stmt = $db->query("SELECT id_instrutor, nome, area, email, telefone, status FROM instrutores ORDER BY nome ASC");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function contar() {
        $db = Database::getConnection();
        $stmt = $db->query("SELECT COUNT(*) as total FROM instrutores");
        $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
        return $resultado['total'] ?? 0;
    }

    public static function salvar($nome, $area, $email, $telefone, $status = 'Ativo') {
        $db = Database::getConnection();
        $sql = "INSERT INTO instrutores (nome, area, email, telefone, status) 
                VALUES (:nome, :area, :email, :telefone, :status)";
        
        $stmt = $db->prepare($sql);
        return $stmt->execute([
            ':nome'     => $nome,
            ':area'     => $area,
            ':email'    => $email,
            ':telefone' => $telefone,
            ':status'   => $status
        ]);
    }
}