<?php
require_once __DIR__ . '/../Model/Usuario.php';

class AuthController {
    
    public function login() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
            $senha = $_POST['senha'] ?? '';

            if ($email && $senha) {
                $usuario = Usuario::buscarPorEmail($email);

                if ($usuario && password_verify($senha, $usuario['senha'])) {
                    $_SESSION['usuario_id'] = $usuario['id'];
                    $_SESSION['usuario_nome'] = $usuario['nome'];
                    $_SESSION['usuario_perfil'] = $usuario['perfil'] ?? 'Administrador';

                    header('Location: index.php?rota=dashboard');
                    exit;
                }
            }

            $erro = "E-mail ou senha inválidos.";
            require_once __DIR__ . '/../index.final.html';
        } else {
            require_once __DIR__ . '/../index.final.html';
        }
    }

    public function logout() {
        unset($_SESSION['usuario_id']);
        unset($_SESSION['usuario_nome']);
        session_destroy();
        
        header('Location: index.php?rota=login');
        exit;
    }
}